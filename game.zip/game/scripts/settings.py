import numpy as np
import math
import pygame as pg
import os
import sys
import time

WIN_RES = (640, 480)
DISPLAY = [320, 240]
FPS = 60